# Replace with your actual bot token
TOKEN = '7534823163:AAEceD0HFpwWwIdst5ff4RhyStZ8CkRtItI'
# Admin ID
ADMIN_ID = 1847934841 